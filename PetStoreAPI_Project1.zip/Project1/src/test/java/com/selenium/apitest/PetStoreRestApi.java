package com.selenium.apitest;

import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.io.File;

import static io.restassured.RestAssured.given;

public class PetStoreRestApi {
    @Test
    public void createPetStoreApiUserSuccess_ReturnsOK()
    {
        Response response = given().header("Content_Type","application/json")
                .header("accept","application/json")
                .body("{\n"+
                "\"id\": 0,\n"+
                "\"username\": \"RashmiBasawarajChigoni\",\n"+
                "\"firstName\": \"Rashmi\",\n"+
                "\"lastName\": \"Chigoni\",\n"+
                "\"email\": \rashmichigon75@gmail.com\",\n"+
                "\"password\": \"Rashmi$75\",\n"+
                "\"phone\": \"7899435223\",\n"+
                "\"userStatus\": 0\n"+"}")
                .when()
                .post("https://petstore.swagger.io/v2/user");
               response.prettyPrint();
               response.then().assertThat().statusCode(200);
    }
    @Test
    public void loggedInToPetStoreSuccess_ReturnsOK()
    {
        Response response = given().header("accept","application/json")
                .queryParam("user","rashmi")
                .queryParam("pass","rashmib")
                .when()
                .get("https://petstore.swagger.io/v2/user/login?username=rashmi&password=rashmib");
                response.prettyPrint();
                response.then().assertThat().statusCode(200);

    }
    @Test
    public void getUserByNameSuccess_ReturnsOK()
    {
        Response response = given().accept("application/json")
                .pathParam("user","string")
                .when()
                .get("https://petstore.swagger.io/v2/user/string");
                 response.prettyPrint();
                 response.then().statusCode(200);
                 String emailText = response.path("username");
                 System.out.println("userEmail : "+emailText);
    }
    @Test
    public void updateExistingUserInfoSuccess_ReturnOK()
    {
        Response response = given().accept("application/json")
                .contentType("application/json")
                .pathParam("username","string")
                .body("{\n" +
                        "  \"id\": 0,\n" +
                        "  \"username\": \"string\",\n" +
                        "  \"firstName\": \"string\",\n" +
                        "  \"lastName\": \"string\",\n" +
                        "  \"email\": \"string@gmail.com\",\n" +
                        "  \"password\": \"string\",\n" +
                        "  \"phone\": \"string\",\n" +
                        "  \"userStatus\": 0\n" +
                        "}")
                .when()
                .put("https://petstore.swagger.io/v2/user/string");

        response.prettyPrint();
        response.then().assertThat().statusCode(200);
    }
    @Test
    public void deleteUserFromPetStoreSuccess_ReturnsOK()
    {
        Response response = given().accept("application/json")
                .pathParam("username","string")
                .when()
                .delete("https://petstore.swagger.io/v2/user/string");
        response.prettyPrint();
        response.then().assertThat().statusCode(200);
    }
    @Test
    public void uploadImageForPetStoreSuccess_ReturnsOK()
    {
        File file = new File("C:\\Users\\Admin\\Pictures\\Screenshots");
        Response response = given().accept("application/json")
                .multiPart(file)
                .when()
                .post("https://petstore.swagger.io/v2/pet/101/uploadImage");
        response.prettyPrint();
        response.then().statusCode(200);

    }


}
